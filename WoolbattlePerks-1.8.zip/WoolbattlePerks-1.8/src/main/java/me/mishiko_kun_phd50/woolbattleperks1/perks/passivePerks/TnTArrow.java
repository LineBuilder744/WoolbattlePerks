package me.mishiko_kun_phd50.woolbattleperks1.perks.passivePerks;

import me.mishiko_kun_phd50.woolbattleperks1.perks.PassivePerks;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class TnTArrow extends PassivePerks {
    private static final int woolNeeded = 17;
    private static final int arrowsToReady = 10;

    public static ItemStack getPerk(boolean isReady){

        ItemStack tntArrow = new ItemStack(Material.TNT, 1);
        ItemMeta meta = tntArrow.getItemMeta();
        meta.setDisplayName("ExplodingArrow");
        if(isReady){
            meta.addEnchant(Enchantment.DURABILITY, 1, true);
        }
        tntArrow.setItemMeta(meta);

        return tntArrow;
    }
    public static void onUsed(Player player, Projectile projectile){
        onArrow(player, projectile, getPerk(true), getPerk(false), "ExplodingArrow", arrowsToReady, woolNeeded);
    }
}
