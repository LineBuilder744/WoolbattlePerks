package me.mishiko_kun_phd50.woolbattleperks1.perks;

import me.mishiko_kun_phd50.woolbattleperks1.WoolbattlePerks_1;
import me.mishiko_kun_phd50.woolbattleperks1.events.Events;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class ActivePerks extends Perks {

    protected static void onCooldown(Player player, int slot, ItemStack perkItem, ItemStack perkItemReady, short cooldownTime){
        perkItem.setAmount(cooldownTime);
        player.getInventory().setItem(slot, perkItem);

        perkItem.setAmount(1);

        new BukkitRunnable() {
            short count = cooldownTime;
            @Override
            public void run() {
                removeItemOrSetReady(player, perkItem, perkItemReady);
                count--;
                if(count<=0){
                    cancel();
                }
            }
        }.runTaskTimerAsynchronously(WoolbattlePerks_1.getInstance(), 0L, 20L); // Запускаем каждую секунду (20 тиков)
    }
}
