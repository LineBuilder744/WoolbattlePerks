package me.mishiko_kun_phd50.woolbattleperks1.perks.passivePerks;

import me.mishiko_kun_phd50.woolbattleperks1.perks.PassivePerks;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class RocketJump extends PassivePerks {
    public static ItemStack getPerk(){
        ItemStack rocketJump = new ItemStack(Material.RABBIT_FOOT, 1);
        ItemMeta meta = rocketJump.getItemMeta();
        meta.setDisplayName("Rocket Jump");
        meta.addEnchant(Enchantment.DURABILITY, 1, true);
        rocketJump.setItemMeta(meta);

        return rocketJump;
    }
}
