package me.mishiko_kun_phd50.woolbattleperks1.events;

import me.mishiko_kun_phd50.woolbattleperks1.perks.activePerks.*;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;

import org.bukkit.event.player.PlayerInteractEvent;


public class ActivePerksEvents implements Listener {
    @EventHandler
    public void onPerk(PlayerInteractEvent event){
        Player player = event.getPlayer();

        if(event.getAction() == Action.RIGHT_CLICK_AIR || event.getAction() == Action.RIGHT_CLICK_BLOCK){
            int slot = player.getInventory().getHeldItemSlot();
            if(player.getItemInHand().getItemMeta().getDisplayName() != null) {
                // Safety Platform
                if (player.getItemInHand().equals(SafetyPlatform.getPerk(true))) {
                    SafetyPlatform.onUsed(player, slot);
                    event.setCancelled(true);

                // Safety Capsule
                } else if (player.getItemInHand().equals(SafetyCapsule.getPerk(true))) {
                    SafetyCapsule.onUsed(player, slot);
                    event.setCancelled(true);

                // Booster
                } else if (player.getItemInHand().equals(Booster.getPerk(true))) {
                    Booster.onUsed(player, slot);
                    event.setCancelled(true);

                // Rope
                } else if (player.getItemInHand().equals(Rope.getPerk(true))) {
                    Rope.onUsed(player, slot);
                    event.setCancelled(true);

                // Wall Builder
                } else if (player.getItemInHand().equals(WallBuilder.getPerk(true))) {
                    WallBuilder.onUsed(player, slot);
                    event.setCancelled(true);

                // Switcher
                } else if (player.getItemInHand().equals(Switcher.getPerk(true))) {
                    Switcher.onUsed(player, slot);
                    event.setCancelled(true);

                // Arrow Bomb
                } else if (player.getItemInHand().equals(ArrowBomb.getPerk(true))) {
                    ArrowBomb.onUsed(player, slot);
                    event.setCancelled(true);

                // Throwable TnT
                } else if (player.getItemInHand().equals(ThrowableTnT.getPerk(true))) {
                    ThrowableTnT.onUsed(player, slot);
                    event.setCancelled(true);

                // Line Builder
                } else if (player.getItemInHand().equals(LineBuilder.getPerk(true))) {
                    LineBuilder.onUsed(player, slot);
                    event.setCancelled(true);

                // Protecting Sheild
                } else if (player.getItemInHand().equals(ProtectingSheild.getPerk(true))) {
                    ProtectingSheild.onUsed(player, slot);
                    event.setCancelled(true);

                }
            }
        }
    }

}
