package me.mishiko_kun_phd50.woolbattleperks1.events;

import me.mishiko_kun_phd50.woolbattleperks1.perks.passivePerks.HookArrow;
import me.mishiko_kun_phd50.woolbattleperks1.perks.passivePerks.TnTArrow;
import me.mishiko_kun_phd50.woolbattleperks1.perks.passivePerks.WoolRemovingArrow;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityShootBowEvent;
import org.bukkit.inventory.ItemStack;

public class PassivePerksEvents implements Listener {
    @EventHandler
    public void onBow(EntityShootBowEvent event){

        if(event.getEntity() instanceof Player && event.getProjectile() instanceof Projectile){
            Player player = (Player)event.getEntity();
            for (ItemStack stack : player.getInventory().getContents()) {
                if(stack != null){
                    // TnTArrow
                    if (stack.isSimilar(TnTArrow.getPerk(true)) || stack.isSimilar(TnTArrow.getPerk(false)) ) {
                        TnTArrow.onUsed(player, (Projectile) event.getProjectile());
                    }

                    // HookArrow
                    else if (stack.isSimilar(HookArrow.getPerk(true)) || stack.isSimilar(HookArrow.getPerk(false)) ) {
                        HookArrow.onUsed(player, (Projectile) event.getProjectile());
                    }

                    // WoolRemovingArrow
                    else if (stack.isSimilar(WoolRemovingArrow.getPerk(true)) || stack.isSimilar(WoolRemovingArrow.getPerk(false))) {
                        WoolRemovingArrow.onUsed(player, (Projectile) event.getProjectile());
                    }
                }
            }
        }
    }
}
