package me.mishiko_kun_phd50.woolbattleperks1.perks.activePerks;

import me.mishiko_kun_phd50.woolbattleperks1.WoolbattlePerks_1;
import me.mishiko_kun_phd50.woolbattleperks1.perks.ActivePerks;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.*;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.metadata.FixedMetadataValue;
import org.bukkit.util.Vector;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class ThrowableTnT extends ActivePerks {

    static private final int woolNeeded = 17;
    private static final short reloadTime = 10;


    public static ItemStack getPerk(boolean isReady){
        return newPerkItem(Material.TNT, Material.FIREWORK_CHARGE, "Throwable TnT", isReady);
    }

    public static void onUsed(Player player, int slot){

        if(isEnoughWool(player, woolNeeded)){
            removeWool(player, woolNeeded);
            Snowball snowball = player.launchProjectile(Snowball.class);
            snowball.setMetadata("throwableTnT", new FixedMetadataValue(WoolbattlePerks_1.getInstance(), true));

            onCooldown(player, slot, getPerk(false), getPerk(true), reloadTime);

        }
    }
    static public void spawnThrowableTnT(Projectile projectile){
        TNTPrimed tnt = (TNTPrimed) projectile.getWorld().spawnEntity(projectile.getLocation(), EntityType.PRIMED_TNT);
        tnt.setFuseTicks(5);

        tnt.setMetadata("ThrowableTnT", new FixedMetadataValue(WoolbattlePerks_1.getInstance(), true));
    }
}
